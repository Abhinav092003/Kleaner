package com.abhinav.hospitalmanagementsystem.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toolbar;

import com.abhinav.hospitalmanagementsystem.LoginActivity;
import com.abhinav.hospitalmanagementsystem.R;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import de.hdodenhof.circleimageview.CircleImageView;


public class SettingFragment extends Fragment {
    private Toolbar toolbar;
    private TextView type,name,email,phonenumber,userid;
    private CircleImageView profilepic;
    private Button logoutbutton;
    private DatabaseReference databaseReference;










    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile1, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //toolbar = view.findViewById(R.id.toolbar2);
        type = view.findViewById(R.id.type_profile);
        name = view.findViewById(R.id.name_profile);
        email = view.findViewById(R.id.email_profile);
        phonenumber = view.findViewById(R.id.phoneNumber_profile);
        userid = view.findViewById(R.id.userid_profile);
        profilepic = view.findViewById(R.id.profileImage);
        logoutbutton = view.findViewById(R.id.logout_button_profile);


        databaseReference = FirebaseDatabase.getInstance().getReference().child("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    type.setText(snapshot.child("type").getValue().toString());
                    name.setText(snapshot.child("name").getValue().toString());
                    email.setText(snapshot.child("email").getValue().toString());
                    userid.setText(snapshot.child("userid").getValue().toString());
                    phonenumber.setText(snapshot.child("phonenumber").getValue().toString());
                    String imageUrl = snapshot.child("profilepictureurl").getValue().toString();
                    Glide.with(getContext().getApplicationContext()).load(imageUrl).into(profilepic);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        logoutbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}