package com.abhinav.hospitalmanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class Otp_gif_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_gif);

    }
    public void ShowGif(View view) {
       // ImageView imageView = findViewById(R.id.imageView3);
       // Glide.with(this).load(R.drawable.load).into(imageView);
    }

}