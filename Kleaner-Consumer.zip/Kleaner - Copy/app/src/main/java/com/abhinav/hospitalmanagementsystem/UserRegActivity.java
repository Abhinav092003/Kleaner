package com.abhinav.hospitalmanagementsystem;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;


import de.hdodenhof.circleimageview.CircleImageView;

public class UserRegActivity extends AppCompatActivity {
    private TextInputEditText fullname,email,password,regid;
    EditText phoneno;
    private Button button;
    private CircleImageView profile;
    private Uri resultUri;
    private FirebaseAuth mAuth;
    private DatabaseReference userDataBAseref;
    private ProgressDialog loader;

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_reg);
        fullname=findViewById(R.id.loginPassword4);
        email=findViewById(R.id.quantity);
        password=findViewById(R.id.date);
        phoneno=findViewById(R.id.loginPassword5);
        regid=findViewById(R.id.loginPassword7);
        button=findViewById(R.id.register_book);
        profile=findViewById(R.id.profile);
        loader=new ProgressDialog(this);
        mAuth=FirebaseAuth.getInstance();
     //   binding = ActivityPatientRegBinding.inflate(getLayoutInflater());
       // setContentView(binding.getRoot());






        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent,1);
            }


        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String emailid = email.getText().toString().trim();
                final String name = fullname.getText().toString().trim();
                final String patientpassword=password.getText().toString().trim();
                final String phone = phoneno.getText().toString().trim();
                final String userid = regid.getText().toString().trim();


                if ((TextUtils.isEmpty(emailid))){
                    email.setError("Email is Required");
                    return;
                }
                if ((TextUtils.isEmpty(patientpassword))){
                    password.setError("Password is Required");
                    return;
                }
                if((password.getText().toString().trim().length()<6)){
                    password.setError("Minimum 6 character is required");
                    return;
                }

                if ((TextUtils.isEmpty(name))){
                    fullname.setError("Name is Required");
                    return;
                }
                if ((TextUtils.isEmpty(userid))){
                   regid.setError("UserName is Required");
                    return;
                }
//                if ((TextUtils.isEmpty(phone))){
//                    phoneno.setError("Mobile Number is Required");
//                    return;
//                }
                if (! Patterns.EMAIL_ADDRESS.matcher(emailid).matches()){
                    email.setError("Enter Valid Email ID");
                    return;

                }




                if (resultUri==null){
                    Toast.makeText(UserRegActivity.this, "select image", Toast.LENGTH_SHORT).show();
                    return;
                }





                if(resultUri!=null) {
                    loader.setMessage("Registration in progress");
                    loader.setCanceledOnTouchOutside(false);
                    loader.show();







                    mAuth.createUserWithEmailAndPassword(emailid,patientpassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()){
                                String error = task.getException().toString();
                                Toast.makeText(UserRegActivity.this, "Error Occured "+error, Toast.LENGTH_SHORT).show();

                                finish();
                                return;



                               // Intent intent = new Intent(getApplicationContext(),PatientRegActivity.class);
                               // startActivity(intent);
                            }

                            else{
                                String username = mAuth.getCurrentUser().getUid();
                                userDataBAseref = FirebaseDatabase.getInstance().getReference().child("users").child(username);
                                HashMap userInfo = new HashMap();
                                userInfo.put("name",name);
                                userInfo.put("email",emailid);
                                userInfo.put("userid",userid);
                                userInfo.put("phonenumber",phone);
                                userInfo.put("type","patient");

                                userDataBAseref.updateChildren(userInfo).addOnCompleteListener(new OnCompleteListener() {
                                    @Override
                                    public void onComplete(@NonNull Task task) {
                                        if(task.isSuccessful()){
                                            Toast.makeText(UserRegActivity.this, "details Set successfully", Toast.LENGTH_SHORT).show();

                                            if (!phoneno.getText().toString().trim().isEmpty()){
                                                if (phoneno.getText().toString().trim().length()==10){


                                                    mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                                                        @Override
                                                        public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                                                        }

                                                        @Override
                                                        public void onVerificationFailed(@NonNull FirebaseException e) {
                                                            Toast.makeText(UserRegActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                                                        }

                                                        @Override
                                                        public void onCodeSent(@NonNull String backendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {

                                                            Intent intent = new Intent(getApplicationContext(),VerifyEnterOtpActivity.class);
                                                            intent.putExtra("mobile",phoneno.getText().toString().trim());
                                                            intent.putExtra("backendotp",backendotp);
                                                            startActivity(intent);
                                                        }
                                                    };
                                                    PhoneAuthOptions options =
                                                            PhoneAuthOptions.newBuilder(mAuth)
                                                                    .setPhoneNumber("+91" + phoneno.getText().toString().trim())
                                                                    .setTimeout(60L, TimeUnit.SECONDS)
                                                                    .setActivity(UserRegActivity.this)
                                                                    .setCallbacks(mCallbacks)
                                                                    .build();
                                                    PhoneAuthProvider.verifyPhoneNumber(options);


                                                }
                                                else {
                                                    phoneno.setError("enter valid number");
                                                    return;
                                                }
                                            }
                                            else{
                                                phoneno.setError("Enter Mobile Number");
                                                return;
                                            }
                                        }
                                        else{
                                            Toast.makeText(UserRegActivity.this, task.getException().toString(), Toast.LENGTH_SHORT).show();
                                            return;
                                        }
                                        finish();
                                        loader.dismiss();
                                    }
                                });



                                if(resultUri != null){
                                    final StorageReference filepath = FirebaseStorage.getInstance().getReference().child("profile picture").child(username);;
                                    Bitmap bitmap = null;
                                    try {
                                        bitmap= MediaStore.Images.Media.getBitmap(getApplication().getContentResolver(),resultUri);
                                    }catch (IOException e){
                                        e.printStackTrace();

                                    }
                                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                    bitmap.compress(Bitmap.CompressFormat.JPEG, 20,byteArrayOutputStream);
                                    byte[] data = byteArrayOutputStream.toByteArray();

                                    UploadTask uploadTask = filepath.putBytes(data);
                                    uploadTask.addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(UserRegActivity.this, "Image Upload fails", Toast.LENGTH_SHORT).show();
                                            finish();
                                            return;
                                        }
                                    });
                                    uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                        @Override
                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                            if(taskSnapshot.getMetadata() != null){
                                                Task<Uri> result = taskSnapshot.getStorage().getDownloadUrl();
                                                result.addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                    @Override
                                                    public void onSuccess(Uri uri) {
                                                        String imageUrl = uri.toString();
                                                        Map newImageMap =new HashMap();
                                                        newImageMap.put("profilepictureurl",imageUrl);

                                                        userDataBAseref.updateChildren(newImageMap).addOnCompleteListener(new OnCompleteListener() {
                                                            @Override
                                                            public void onComplete(@NonNull Task task) {
                                                                if(task.isSuccessful()){
                                                                  //  Toast.makeText(PatientRegActivity.this, "Registration Succesfull", Toast.LENGTH_SHORT).show();
                                                                }
                                                                else {
                                                                    Toast.makeText(UserRegActivity.this, task.getException().toString(), Toast.LENGTH_SHORT).show();
                                                                    return;
                                                                }
                                                            }
                                                        });
                                                        finish();
                                                    }
                                                });
                                            }
                                        }
                                    });
                                    Intent intent = new Intent(UserRegActivity.this, Otp_gif_Activity.class);
                                    startActivity(intent);
                                    finish();
                                    loader.dismiss();
                                }

                            }

                        }
                    });
                }






            }
        });



    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1&&resultCode== Activity.RESULT_OK && data!=null){
            resultUri=data.getData();
            profile.setImageURI(resultUri);

        }

    }

    public void loginactivity(View view) {
        Intent intent = new Intent(this,LoginActivity.class);
        startActivity(intent);
    }


}