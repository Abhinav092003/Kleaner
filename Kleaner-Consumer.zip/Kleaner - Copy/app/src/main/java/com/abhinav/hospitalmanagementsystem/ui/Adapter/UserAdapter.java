package com.abhinav.hospitalmanagementsystem.ui.Adapter;

public class UserAdapter {

}
