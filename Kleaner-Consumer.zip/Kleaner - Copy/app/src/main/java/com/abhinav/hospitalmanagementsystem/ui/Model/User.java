package com.abhinav.hospitalmanagementsystem.ui.Model;

public class User {
    String name,email,type,phonenumber,userid,profilepictureurl;

    public User() {
    }

    public User(String name, String email, String type, String phonenumber, String userid, String profilepictureurl) {
        this.name = name;
        this.email = email;
        this.type = type;
        this.phonenumber = phonenumber;
        this.userid = userid;
        this.profilepictureurl = profilepictureurl;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getProfilepictureurl() {
        return profilepictureurl;
    }

    public void setProfilepictureurl(String profilepictureurl) {
        this.profilepictureurl = profilepictureurl;
    }
}
