package com.abhinav.kleaner_private;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class LastActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_last);
    }
}